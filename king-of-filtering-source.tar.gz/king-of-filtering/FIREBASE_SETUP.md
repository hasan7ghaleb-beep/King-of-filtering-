# إعداد Firebase - دليل شامل

هذا الدليل يساعدك على ربط التطبيق بـ Firebase Realtime Database.

## ✅ المتطلبات

- حساب Google
- وصول إلى [Firebase Console](https://console.firebase.google.com/)

## 📋 خطوات الإعداد

### الخطوة 1: إنشاء مشروع Firebase

1. اذهب إلى [Firebase Console](https://console.firebase.google.com/)
2. اضغط على **"إنشاء مشروع"** (Create Project)
3. أدخل اسم المشروع (مثلاً: `king-of-filtering`)
4. اختر الدولة/المنطقة
5. اضغط **"إنشاء"** (Create)

### الخطوة 2: تفعيل Realtime Database

1. من القائمة الجانبية، اختر **"Build"** ثم **"Realtime Database"**
2. اضغط **"إنشاء قاعدة بيانات"** (Create Database)
3. اختر الموقع الجغرافي الأقرب (مثلاً: `europe-west1`)
4. اختر **"ابدأ في وضع الاختبار"** (Start in test mode) للتطوير
5. اضغط **"تفعيل"** (Enable)

### الخطوة 3: الحصول على بيانات الاتصال

1. من القائمة الجانبية، اختر **"Project Settings"** (⚙️)
2. اختر تبويب **"Service Accounts"**
3. اضغط على **"Web"** لإضافة تطبيق ويب
4. انسخ كود الإعداد (Firebase Config)

### الخطوة 4: تحديث الملف

استبدل بيانات Firebase في `client/public/index.html`:

```javascript
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_AUTH_DOMAIN",
  databaseURL: "YOUR_DATABASE_URL",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_STORAGE_BUCKET",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};
```

### الخطوة 5: قواعد الأمان

#### للتطوير (غير آمن - للاختبار فقط):

1. اذهب إلى **Realtime Database** → **Rules**
2. استبدل القواعس بـ:

```json
{
  "rules": {
    "regions": {
      "$region": {
        "tasks": {
          ".read": true,
          ".write": true
        },
        "users": {
          ".read": true,
          ".write": true
        },
        "perf": {
          ".read": true,
          ".write": true
        }
      }
    }
  }
}
```

3. اضغط **"Publish"**

#### للإنتاج (آمن - مع المصادقة):

```json
{
  "rules": {
    "regions": {
      "$region": {
        "tasks": {
          ".read": "auth != null",
          ".write": "auth != null"
        },
        "users": {
          ".read": "auth != null",
          ".write": "auth.uid === $uid"
        },
        "perf": {
          ".read": "auth != null",
          ".write": "auth != null"
        }
      }
    }
  }
}
```

## 🔐 تفعيل المصادقة (اختياري)

### تفعيل Google Sign-In:

1. اذهب إلى **Authentication** → **Sign-in method**
2. فعّل **Google**
3. أضف بريدك الإلكتروني كمختبر

### تفعيل البريد الإلكتروني/كلمة المرور:

1. اذهب إلى **Authentication** → **Sign-in method**
2. فعّل **Email/Password**

## 💾 تفعيل Cloud Storage (اختياري)

للسماح بتحميل الصور والملفات:

1. اذهب إلى **Storage**
2. اضغط **"ابدأ"** (Get Started)
3. اختر الموقع الجغرافي
4. اضغط **"تالي"** (Next)

### قواعس Storage:

```
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /{allPaths=**} {
      allow read, write: if request.auth != null;
    }
  }
}
```

## 🧪 اختبار الاتصال

1. شغّل التطبيق: `pnpm dev`
2. افتح المتصفح على `http://localhost:3000`
3. افتح **Developer Console** (F12)
4. تحقق من الرسائل:
   - ✅ `Firebase initialized successfully`
   - ✅ `Database URL: https://...`

## 📊 مراقبة البيانات

### عرض البيانات في Firebase Console:

1. اذهب إلى **Realtime Database**
2. ستجد البنية التالية:

```
regions/
├── central/
│   ├── tasks/
│   │   ├── task_id_1
│   │   ├── task_id_2
│   └── users/
├── north/
│   ├── tasks/
│   └── users/
└── ...
```

## 🚀 النشر على Vercel

عند النشر على Vercel، لا تحتاج إلى متغيرات بيئة إضافية لأن بيانات Firebase مضمنة في الملف.

## ⚠️ نصائح الأمان

1. **لا تشارك مفاتيح Firebase** - هي عامة لكن محمية بقواعس الأمان
2. **استخدم قواعس صارمة** - لا تستخدم `true` للقراءة/الكتابة في الإنتاج
3. **فعّل المصادقة** - استخدم Firebase Auth في الإنتاج
4. **راقب الاستخدام** - تحقق من استخدام قاعدة البيانات في Firebase Console

## 🆘 استكشاف الأخطاء

### المشكلة: "Permission denied"

**الحل**: تحقق من قواعس الأمان في Firebase Console

### المشكلة: البيانات لا تُحفظ

**الحل**: 
1. تحقق من اتصال الإنترنت
2. تحقق من صحة بيانات Firebase Config
3. افتح Firebase Console وتحقق من الأخطاء

### المشكلة: "CORS error"

**الحل**: Firebase يدعم CORS افتراضياً، لكن تأكد من أن النطاق مسموح به

## 📚 موارد إضافية

- [Firebase Documentation](https://firebase.google.com/docs)
- [Realtime Database Guide](https://firebase.google.com/docs/database)
- [Firebase Security Rules](https://firebase.google.com/docs/database/security)

---

**تم آخر تحديث**: مارس 2026
