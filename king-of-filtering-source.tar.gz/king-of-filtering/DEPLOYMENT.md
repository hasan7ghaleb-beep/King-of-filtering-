# دليل النشر - GitHub و Vercel

هذا الدليل يساعدك على نشر التطبيق على GitHub و Vercel.

## 📦 النشر على GitHub

### الخطوة 1: إنشاء مستودع GitHub

1. اذهب إلى [GitHub](https://github.com)
2. اضغط على **"New"** لإنشاء مستودع جديد
3. أدخل اسم المستودع: `king-of-filtering`
4. اختر **"Public"** أو **"Private"**
5. اضغط **"Create repository"**

### الخطوة 2: ربط المشروع المحلي

```bash
# انتقل إلى مجلد المشروع
cd king-of-filtering

# تهيئة Git (إذا لم يكن مهيأً)
git init

# إضافة المستودع البعيد
git remote add origin https://github.com/yourusername/king-of-filtering.git

# إضافة الملفات
git add .

# Commit الأول
git commit -m "Initial commit: King of Filtering app with Firebase integration"

# دفع إلى GitHub
git branch -M main
git push -u origin main
```

### الخطوة 3: إعداد GitHub Actions (اختياري)

أنشئ ملف `.github/workflows/deploy.yml`:

```yaml
name: Deploy to Vercel

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: pnpm/action-setup@v2
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
          cache: 'pnpm'
      
      - name: Install dependencies
        run: pnpm install
      
      - name: Build
        run: pnpm build
      
      - name: Deploy to Vercel
        uses: amondnet/vercel-action@v20
        with:
          vercel-token: ${{ secrets.VERCEL_TOKEN }}
          vercel-org-id: ${{ secrets.VERCEL_ORG_ID }}
          vercel-project-id: ${{ secrets.VERCEL_PROJECT_ID }}
```

## 🚀 النشر على Vercel

### الطريقة 1: من خلال Vercel Dashboard (الأسهل)

1. اذهب إلى [Vercel](https://vercel.com)
2. اضغط على **"New Project"**
3. اختر **"Import Git Repository"**
4. ابحث عن `king-of-filtering` وحدده
5. اضغط **"Import"**
6. في **"Configure Project"**:
   - **Framework Preset**: Vite
   - **Build Command**: `pnpm build`
   - **Output Directory**: `dist`
7. اضغط **"Deploy"**

### الطريقة 2: من خلال Vercel CLI

```bash
# تثبيت Vercel CLI
npm i -g vercel

# تسجيل الدخول
vercel login

# النشر
vercel

# للإنتاج
vercel --prod
```

### الطريقة 3: من خلال GitHub Integration

1. اذهب إلى [Vercel](https://vercel.com)
2. اضغط على **"New Project"**
3. اختر **"Import Git Repository"**
4. ربط حسابك على GitHub
5. اختر المستودع `king-of-filtering`
6. اضغط **"Import"** ثم **"Deploy"**

## ⚙️ إعدادات Vercel

### المتغيرات البيئية

إذا كنت تستخدم متغيرات بيئية:

1. اذهب إلى **Project Settings** → **Environment Variables**
2. أضف المتغيرات:

```
VITE_FIREBASE_API_KEY=your_key
VITE_FIREBASE_AUTH_DOMAIN=your_domain
VITE_FIREBASE_DATABASE_URL=your_url
VITE_FIREBASE_PROJECT_ID=your_project_id
VITE_FIREBASE_STORAGE_BUCKET=your_bucket
VITE_FIREBASE_MESSAGING_SENDER_ID=your_sender_id
VITE_FIREBASE_APP_ID=your_app_id
```

### النطاق المخصص

1. اذهب إلى **Domains**
2. اضغط **"Add Domain"**
3. أدخل اسم النطاق (مثلاً: `king-of-filtering.com`)
4. اتبع التعليمات لربط DNS

## 🔄 التحديثات التلقائية

### مع GitHub Integration:

عند دفع تغييرات إلى GitHub:

```bash
git add .
git commit -m "Update: Add new feature"
git push origin main
```

Vercel سيقوم تلقائياً بـ:
1. بناء المشروع
2. تشغيل الاختبارات
3. نشر النسخة الجديدة

## 📊 مراقبة الأداء

### في Vercel Dashboard:

1. اذهب إلى **Analytics**
2. شاهد:
   - **Response Time**: سرعة الاستجابة
   - **Requests**: عدد الطلبات
   - **Bandwidth**: استهلاك البيانات
   - **Errors**: الأخطاء

### في Firebase Console:

1. اذهب إلى **Database** → **Usage**
2. شاهد:
   - عدد الكتابات/القراءات
   - استهلاك التخزين
   - الأخطاء

## 🔐 الأمان

### قائمة التحقق:

- [ ] تفعيل HTTPS (Vercel يفعله افتراضياً)
- [ ] إضافة قواعس أمان Firebase صارمة
- [ ] عدم مشاركة المفاتيح السرية
- [ ] تفعيل المصادقة في الإنتاج
- [ ] استخدام متغيرات البيئة للمفاتيح

### إضافة رؤوس الأمان:

في `vercel.json`:

```json
"headers": [
  {
    "source": "/(.*)",
    "headers": [
      {
        "key": "X-Content-Type-Options",
        "value": "nosniff"
      },
      {
        "key": "X-Frame-Options",
        "value": "SAMEORIGIN"
      },
      {
        "key": "X-XSS-Protection",
        "value": "1; mode=block"
      }
    ]
  }
]
```

## 🆘 استكشاف الأخطاء

### المشكلة: "Build failed"

**الحل**:
1. افتح سجلات البناء في Vercel
2. تحقق من الأخطاء
3. تأكد من أن `pnpm install` يعمل محلياً

### المشكلة: "Firebase not initialized"

**الحل**:
1. تحقق من بيانات Firebase في `index.html`
2. تأكد من أن Firebase SDK محمل
3. افتح Developer Console وتحقق من الأخطاء

### المشكلة: "CORS error"

**الحل**:
1. تحقق من قواعس Firebase
2. أضف النطاق إلى قائمة النطاقات المسموحة

## 📈 التحسينات المستقبلية

- [ ] إضافة CDN للصور
- [ ] تحسين الأداء مع Service Workers
- [ ] إضافة اختبارات تلقائية
- [ ] إضافة CI/CD متقدم
- [ ] مراقبة الأخطاء مع Sentry

## 📚 موارد إضافية

- [Vercel Documentation](https://vercel.com/docs)
- [GitHub Pages Guide](https://pages.github.com/)
- [Firebase Hosting](https://firebase.google.com/docs/hosting)

---

**تم آخر تحديث**: مارس 2026

**ملاحظة**: استبدل `yourusername` برقم حسابك على GitHub.
