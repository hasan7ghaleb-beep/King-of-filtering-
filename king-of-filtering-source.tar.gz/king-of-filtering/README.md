# ملك الفلترة - King of Filtering

تطبيق ويب متقدم لإدارة المشاريع والمهام مع تكامل Firebase Realtime Database للمزامنة السحابية.

## 🎯 الميزات الرئيسية

- ✅ **إدارة المهام المتقدمة** - إنشاء وتعديل وحذف المهام بسهولة
- 🌍 **دعم متعدد المناطق** - إدارة مشاريع منفصلة لكل منطقة جغرافية
- ☁️ **مزامنة Firebase** - حفظ البيانات تلقائياً على Firebase Realtime Database
- 📊 **إحصائيات مباشرة** - عرض إحصائيات المهام والميزانية في الوقت الفعلي
- 📤 **تصدير البيانات** - تصدير البيانات بصيغ متعددة (JSON, Excel, ZIP)
- 🎨 **واجهة عربية احترافية** - تصميم حديث وسهل الاستخدام
- 💾 **التخزين المحلي** - حفظ البيانات محلياً مع المزامنة السحابية

## 🚀 البدء السريع

### المتطلبات

- Node.js 18+ أو أحدث
- pnpm (أو npm/yarn)
- حساب Firebase (اختياري للمزامنة السحابية)

### التثبيت

```bash
# استنساخ المشروع
git clone https://github.com/yourusername/king-of-filtering.git
cd king-of-filtering

# تثبيت المتطلبات
pnpm install

# تشغيل خادم التطوير
pnpm dev
```

سيتم فتح التطبيق على `http://localhost:3000`

### البناء للإنتاج

```bash
# بناء المشروع
pnpm build

# معاينة البناء
pnpm preview
```

## 📁 هيكل المشروع

```
king-of-filtering/
├── client/
│   ├── public/
│   │   ├── index.html          # ملف HTML الرئيسي مع Firebase SDK
│   │   └── favicon.ico
│   ├── src/
│   │   ├── App.tsx
│   │   ├── main.tsx
│   │   └── index.css
│   └── index.html
├── server/
│   └── index.ts                # خادم Express (للإنتاج)
├── package.json
├── vercel.json                 # إعدادات Vercel
├── .gitignore
└── README.md
```

## 🔧 إعدادات Firebase

### إعداد قاعدة البيانات

1. انتقل إلى [Firebase Console](https://console.firebase.google.com/)
2. أنشئ مشروع جديد أو استخدم مشروع موجود
3. فعّل Realtime Database
4. انسخ بيانات الاتصال من إعدادات المشروع

### قواعد الأمان

أضف القواعد التالية في Firebase Console:

```json
{
  "rules": {
    "regions": {
      "$region": {
        "tasks": {
          ".read": true,
          ".write": true
        },
        "users": {
          ".read": true,
          ".write": true
        },
        "perf": {
          ".read": true,
          ".write": true
        }
      }
    }
  }
}
```

⚠️ **ملاحظة أمان**: هذه القواعس للتطوير فقط. في الإنتاج، استخدم قواعد أمان أكثر صرامة مع المصادقة.

## 📝 الاستخدام

### إضافة مهمة جديدة

1. اختر المنطقة من الشاشة الأولى
2. اضغط على زر "➕ إضافة مهمة"
3. أدخل البيانات المطلوبة (العنوان، الوصف، الأولوية)
4. سيتم حفظ المهمة تلقائياً

### تصدير البيانات

- **JSON**: تصدير البيانات بصيغة JSON
- **Excel**: تصدير البيانات بصيغة جداول Excel
- **ZIP**: تصدير جميع البيانات مع الملفات المرفقة

## 🌐 النشر

### على Vercel

```bash
# تثبيت Vercel CLI
npm i -g vercel

# النشر
vercel
```

أو ربط المشروع مباشرة من [Vercel Dashboard](https://vercel.com/dashboard)

### على GitHub Pages

```bash
# بناء المشروع
pnpm build

# دفع الملفات إلى GitHub
git add .
git commit -m "Initial commit"
git push origin main
```

## 🔐 المتغيرات البيئية

أنشئ ملف `.env.local` بالمتغيرات التالية:

```env
VITE_FIREBASE_API_KEY=your_api_key
VITE_FIREBASE_AUTH_DOMAIN=your_auth_domain
VITE_FIREBASE_DATABASE_URL=your_database_url
VITE_FIREBASE_PROJECT_ID=your_project_id
VITE_FIREBASE_STORAGE_BUCKET=your_storage_bucket
VITE_FIREBASE_MESSAGING_SENDER_ID=your_sender_id
VITE_FIREBASE_APP_ID=your_app_id
```

## 🛠️ التطوير

### الأوامر المتاحة

```bash
pnpm dev          # تشغيل خادم التطوير
pnpm build        # بناء المشروع
pnpm preview      # معاينة البناء
pnpm check        # فحص TypeScript
pnpm format       # تنسيق الكود
```

### الهيكل التقني

- **Frontend**: React 19 + Vite + Tailwind CSS
- **Backend**: Express.js (اختياري)
- **Database**: Firebase Realtime Database
- **Storage**: Firebase Storage
- **Authentication**: Firebase Auth (اختياري)

## 📱 التوافقية

- ✅ Chrome/Edge (آخر إصدار)
- ✅ Firefox (آخر إصدار)
- ✅ Safari (آخر إصدار)
- ✅ الهواتف الذكية (iOS/Android)

## 🐛 الإبلاغ عن الأخطاء

إذا واجهت أي مشاكل، يرجى فتح issue على GitHub مع تفاصيل المشكلة والخطوات لإعادة إنتاجها.

## 📄 الترخيص

هذا المشروع مرخص تحت MIT License - انظر ملف LICENSE للتفاصيل.

## 👨‍💻 المساهمة

نرحب بالمساهمات! يرجى:

1. Fork المشروع
2. أنشئ فرع جديد (`git checkout -b feature/amazing-feature`)
3. Commit التغييرات (`git commit -m 'Add amazing feature'`)
4. Push إلى الفرع (`git push origin feature/amazing-feature`)
5. فتح Pull Request

## 📞 التواصل

للأسئلة والاستفسارات، يرجى التواصل عبر:
- البريد الإلكتروني: support@example.com
- GitHub Issues: [king-of-filtering/issues](https://github.com/yourusername/king-of-filtering/issues)

---

**تم آخر تحديث**: مارس 2026

**الإصدار الحالي**: 1.0.0
